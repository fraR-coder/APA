#ifndef UF_H
#define UF_H

void  UFinit(int N);
int   UFfind(int p, int q);
void  UFunion(int p, int q);
void  UFfree(void);

#endif


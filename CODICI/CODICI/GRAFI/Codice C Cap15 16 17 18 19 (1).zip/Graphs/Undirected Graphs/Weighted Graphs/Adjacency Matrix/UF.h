#ifndef UF_H
#define UF_H

void  UFinit(int N);
void  UFfree();
int   UFfind(int p, int q);
void  UFunion(int p, int q);

#endif

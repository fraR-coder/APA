void BubbleSort(Item A[], int N);
void OptBubbleSort(Item A[], int N);
void SelectionSort(Item A[], int N);
void InsertionSort(Item A[], int N);
void ShellSort(Item A[], int N);
void CountingSort(Item A[], Item B[], int C[], int N, int k);
